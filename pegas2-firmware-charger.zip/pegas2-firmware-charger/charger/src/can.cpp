#include "can.h"
// #include "system.h"
#include "macros.h"
#include "charge.h"

#include <uavcan.h>

#include <cstring>

#include "gpio_setup.h"
#include "../../libopencm3/include/libopencm3/stm32/f1/nvic.h"
#include "../../libopencm3/include/libopencm3/stm32/rcc.h"
#include "../../libopencm3/include/libopencm3/stm32/gpio.h"

uint8_t can_data[8] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
struct p_s pover_supply;
BatteryInfo b_i;
BatteryInfoAux b_i_a;

uint32_t last_message_battery = 0;
uint32_t last_message_dc = 0;
uint8_t dc_connect = 0;
uint8_t battary_connect = 0;

std::unique_ptr<UAVCAN> UAVCAN::instance = std::make_unique<UAVCAN>();

void can_setup(void)
{
    /* Enable peripheral clocks. */
    rcc_periph_clock_enable(RCC_AFIO);
    rcc_periph_clock_enable(RCC_GPIOB);
    rcc_periph_clock_enable(RCC_CAN);

    // CAN1 -----------------------------------------------------------
    AFIO_MAPR |= AFIO_MAPR_CAN1_REMAP_PORTB;

    /* Configure CAN pin: RX (input pull-up). */
    gpio_set_mode(GPIO_BANK_CAN1_PB_RX, GPIO_MODE_INPUT,
                  GPIO_CNF_INPUT_PULL_UPDOWN, GPIO_CAN1_PB_RX);
    gpio_set(GPIOB, GPIO_CAN1_PB_RX);

    /* Configure CAN pin: TX. */
    gpio_set_mode(GPIO_BANK_CAN1_PB_TX, GPIO_MODE_OUTPUT_50_MHZ,
                  GPIO_CNF_OUTPUT_ALTFN_PUSHPULL, GPIO_CAN1_PB_TX);
    // CAN1 -----------------------------------------------------------
    /* NVIC setup. */

    // CAN1 -----------------------------------------------------------
    /* Reset CAN. */
    can_reset(CAN1);

    // CAN1 -----------------------------------------------------------
    /* CAN cell init. */
    if (can_init(CAN1,
                 false, // time triggered mode
                 false, // auto buss off
                 false, // auto wakeup
                 true,  // disable auto retransmit
                 false, // receive FIFO locked
                 false, // transmit FIFO priority
                 CAN_BTR_SJW_1TQ,
                 CAN_BTR_TS1_13TQ,
                 CAN_BTR_TS2_2TQ,
                 16,     /* BRP+1: Baud rate prescaler */
                 false,  /* loopback mode */
                 false)) /* silent mode */
    {

        /* Die because we failed to initialize. */
        while (1)
        {
            // blink();
        }
        // printf("Can init error \r\n");
        // delay(1000);
    }

    /* CAN filter 0 init. */
    can_filter_id_mask_32bit_init(
        0,     /* Filter ID */
        0,     /* CAN ID */
        0,     /* CAN ID mask */
        1,     /* FIFO assignment (here: FIFO1) */
        true); /* Enable the filter. */

    /* Enable CAN RX interrupt. */
    nvic_enable_irq(NVIC_CAN_RX1_IRQ);
    nvic_set_priority(NVIC_CAN_RX1_IRQ, 1);
    can_enable_irq(CAN1, CAN_IER_FMPIE1);
}

extern "C" void can_rx1_isr(void)
{
    if (CAN_RF1R(CAN1) & CAN_RF1R_FMP1_MASK)
    {
        uint32_t id;
        bool ext, rtr;
        uint8_t fmi, length, data[8];

        can_receive(CAN1, 1, false, &id, &ext, &rtr, &fmi, &length, data, NULL);

        uint32_t m_i = MAIN_INDEX(data); // main_index
        uint32_t value = VALUE(data);

        // if (id == 0x1081807E)
        // {
        // printf("mi: 0x%x, val: 0x%x\r\n", m_i, value);
        // }

        switch (m_i)
        {
        case 0x21:
            // printf("EROOR!!!\r\n");
            // printf("main_index: 0x%X, value: %d comment: ", m_i, value);
            // printf("0x21\r\n");
            break;
        case 0x0E:
            // printf("main_index: 0x%X, value: %d comment: ", m_i, value);
            // printf("0E\r\n");
            break;
        case 0x70:
            pover_supply.input_power = value;
            last_message_dc = millis();
            dc_connect = 1;
            // printf("main_index: 0x%X, value: %d comment: ", m_i, value / 1024);
            // printf("Input Power\r\n");
            break;
        case 0x71:
            pover_supply.input_freq = value;
            last_message_dc = millis();
            dc_connect = 1;
            // printf("main_index: 0x%X, value: %d comment: ", m_i, value / 1024);
            // printf("Input Freq\r\n");
            break;
        case 0x72:
            pover_supply.input_current = value;
            last_message_dc = millis();
            dc_connect = 1;
            // printf("main_index: 0x%X, value: %d comment: ", m_i, value / 1024);
            // printf("Input Current\r\n");
            break;
        case 0x73:
            pover_supply.output_power = value;
            last_message_dc = millis();
            dc_connect = 1;
            // printf("main_index: 0x%X, value: %d comment: ", m_i, value / 1024);
            // printf("Output Power\r\n");
            break;
        case 0x74:
            pover_supply.efficiency = value;
            last_message_dc = millis();
            dc_connect = 1;
            // printf("main_index: 0x%X, value: %d comment: ", m_i, value / 1024);
            // printf("Efficiency\r\n");
            break;
        case 0x75:
            pover_supply.output_voltage = value;
            last_message_dc = millis();
            dc_connect = 1;
            // printf("main_index: 0x%X, value: %d comment: ", m_i, value / 1024);
            // printf("Output Voltage\r\n");
            break;
        case 0x76:
            pover_supply.maximum_output_current = value;
            last_message_dc = millis();
            dc_connect = 1;
            // printf("main_index: 0x%X, value: %d comment: ", m_i, value / 1024);
            // printf("Output Current Max\r\n");
            break;
        case 0x78:
            pover_supply.input_voltage = value;
            last_message_dc = millis();
            dc_connect = 1;
            // printf("main_index: 0x%X, value: %d comment: ", m_i, value / 1024);
            // printf("Imput Voltage\r\n");
            break;
        case 0x7F:
            pover_supply.output_stage_temperature = value;
            last_message_dc = millis();
            dc_connect = 1;
            // printf("main_index: 0x%X, value: %d comment: ", m_i, value / 1024);
            // printf("Output Temperature\r\n");
            break;
        case 0x80:
            pover_supply.input_stage_temperature = value;
            last_message_dc = millis();
            dc_connect = 1;
            // printf("main_index: 0x%X, value: %d comment: ", m_i, value / 1024);
            // printf("Input Stage Temperature\r\n");
            break;
        case 0x81:
        case 0x82:
            pover_supply.output_current = value;
            last_message_dc = millis();
            dc_connect = 1;
            // printf("main_index: 0x%X, value: %d comment: ", m_i, value / 1024);
            // printf("Output Current\r\n");
            break;
        case 0x83:
            // printf("main_index: 0x%X, value: %d comment: ", m_i, value / 1024);
            // printf("Unknown-normally zero\r\n");
            break;

        default:

            break;
        }

        can_fifo_release(CAN1, 1);
    }
}

void can_tr_mesage(uint32_t addres, uint8_t command, uint8_t m_index, uint32_t value)
{
    SET_COMMAND_INDEX(can_data, command);
    SET_MAIN_INDEX(can_data, m_index);
    SET_VALUE(can_data, value);
    // printf("%d\r\n", value);
    can_transmit(CAN1, addres, true, false, 8, can_data);
    // while (can_transmit(CAN1, addres, true, false, 8, can_data) == -1)
    // {
    //     for (size_t i = 0; i < 500000; ++i)
    //     {
    //         __asm__("NOP");
    //     }
    // }
}

void subscribe_messages()
{
    // uavcan.protocol.NodeStatus
    // UAVCAN::add_handler(UAVCAN_NODE_STATUS_DATA_TYPE_ID,
    //                     0,
    //                     [](CanardInstance *ins,
    //                        CanardRxTransfer *transfer)
    //                     {
    //                         last_message_battery = millis();
    //                         battary_connect = 1;
    //                         // printf("uavcan.protocol.NodeStatus\r\n");

    //                         // NodeStatus ns;

    //                         // uint8_t counter = 0;
    //                         // for (size_t i = 0; i < 7; ++i)
    //                         // {
    //                         //     ns.buff[counter] = transfer->payload_head[i];
    //                         //     ++counter;
    //                         // }

    //                         // while (1)
    //                         // {

    //                         //     if (transfer->payload_middle == nullptr)
    //                         //     {
    //                         //         break;
    //                         //     }

    //                         //     for (size_t i = 0; i < 7; ++i)
    //                         //     {
    //                         //         ns.buff[counter] = transfer->payload_middle->data[i];
    //                         //         ++counter;
    //                         //     }

    //                         //     transfer->payload_middle = transfer->payload_middle->next;
    //                         // }

    //                         // for (size_t i = 0; i < 7; ++i)
    //                         // {
    //                         //     ns.buff[counter] = transfer->payload_tail[i];
    //                         //     ++counter;
    //                         // }

    //                         // printf("healt: %d, mode: %d, upt_sec: %d, vssc: %d\r\n",
    //                         //        ns.status.health,
    //                         //        ns.status.mode,
    //                         //        ns.status.uptime_sec,
    //                         //        ns.status.vendor_specific_status_code);
    //                     });
    // ardupilot.equipment.power.BatteryInfoAux
    UAVCAN::add_handler(UAVCAN_PROTOCOL_CELLS_INFO_ID,
                        UAVCAN_PROTOCOL_CELLS_INFO_SIGNATURE,
                        [](CanardInstance *ins,
                           CanardRxTransfer *transfer)
                        {
                            // memcpy(b_i_a.buff, transfer->payload_head, 5);

                            memcpy(b_i_a.buff + 5, transfer->payload_middle->data, 28);

                            // transfer->payload_middle = transfer->payload_middle->next;

                            // memcpy(b_i_a.buff + 33, transfer->payload_middle->data, 14);

                            last_message_battery = millis();
                            battary_connect = 1;

                        });

    // uavcan.equipment.power.BatteryInfo
    UAVCAN::add_handler(UAVCAN_PROTOCOL_BATTERY_INFO_ID,
                        UAVCAN_PROTOCOL_BATTERY_INFO_SIGNATURE,
                        [](CanardInstance *ins,
                           CanardRxTransfer *transfer)
                        {

                            memcpy(b_i.buff, transfer->payload_head, 5);

                            memcpy(b_i.buff + 5, transfer->payload_middle->data, 14);

                            memcpy(b_i.buff + 19, transfer->payload_tail, 4);

                            // last_message_battery = millis();
                            // battary_connect = 1;
                        });
}

void dc_loop()
{
    PERIOD(DC_LOOP_TIMEOUT);

    can_tr_mesage(0x108040FE, 0x00, 0x00, 0x00000000);
}

bool check_connect_dc()
{

    if (millis() - last_message_dc >= CONNECTION_TIMEOUT)
    {
        // printf("No connect DC");
        dc_connect = 0;
        flag_charge = 0;
        return false;
    }

    return true;
}
