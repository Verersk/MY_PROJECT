#include "button.h"
#include "screen.h"
#include "can.h"
#include "charge.h"
#include "uart.h"

Button2 v_button_stop;
Button2 v_button_left;
Button2 v_button_right;
Button2 v_button_ok;

bool setting_flag = false;

void button_setup()
{
    v_button_stop.begin(BTN_VIRTUAL_PIN);
    // v_button_stop.setLongClickTime(3000);
    v_button_stop.setButtonStateFunction([]() -> uint8_t
                                         { return static_cast<uint8_t>(button_stop->get_state()); });
    v_button_stop.setReleasedHandler([](Button2 &btn)
                                    { 
                                        flag_charge = 0;
                                        charge_complite = 0; 
                                        post_charge = 0;
                                    });

    v_button_left.begin(BTN_VIRTUAL_PIN);
    // v_button_left.setLongClickTime(1000);
    v_button_left.setButtonStateFunction([]() -> uint8_t
                                         { return static_cast<uint8_t>(button_left->get_state()); });
    v_button_left.setReleasedHandler([](Button2 &btn)
                                    {
                                        if (setting_flag ) {
                                            if (max_current > 8.0f) {
                                                max_current -= 1.0f;
                                            }
                                        } else {
                                            --screen_data;
                                            if(screen_data > 2)
                                            screen_data = 2;                                             
                                        }

                                    });

    v_button_right.begin(BTN_VIRTUAL_PIN);
    // v_button_right.setLongClickTime(1000);
    v_button_right.setButtonStateFunction([]() -> uint8_t
                                          { return static_cast<uint8_t>(button_right->get_state()); });
    v_button_right.setReleasedHandler([](Button2 &btn)
                                    {
                                        if (setting_flag) {
                                            if (max_current < 55.0f){
                                                max_current += 1.0f;
                                            }
                                        } else {
                                            ++screen_data;
                                            if(screen_data > 2)
                                            screen_data = 0;
                                        }
 });

    v_button_ok.begin(BTN_VIRTUAL_PIN);
    // v_button_ok.setLongClickTime(3000);
    v_button_ok.setButtonStateFunction([]() -> uint8_t
                                       { return static_cast<uint8_t>(button_ok->get_state()); });

    v_button_ok.setReleasedHandler([](Button2 &btn)
                                   {
                                        if (screen_data == 2 && setting_flag) {
                                            setting_flag = false;
                                        } else if (screen_data == 2) {
                                            setting_flag = true;
                                        } else {
                                            switch (check_connect_dc()) {
                                                case 0:
                                                    dc_connect = 0;
                                                    flag_charge = 0;
                                                    
                                                    break;
                                                case 1:
                                                    flag_charge = 1;
                                                    break;

                                                default:
                                                    break;
                                            }

                                            switch (check_connect_bms()) {
                                                case 0:
                                                    bms_connect = 0;
                                                    flag_charge = 0;
                                                    break;
                                                case 1:
                                                    flag_charge = 1;
                                                    break;

                                                default:
                                                    break;
                                            }
                                        }
                                    });
}