#include "uart.h"
#include "gpio_setup.h"
#include <cstring>

#define BASIC_INFORMATION_AND_STATUS    0x03
#define VOLTAGE_OF_CELL_BLOCK           0x04
#define BMS_VERSION                     0x05

#define READ                            0xA5
#define WRITE                           0x5A

#define START_CODE                      0xDD
#define END_CODE                        0x77

extern bool bms_connect = false;
uint32_t last_message_bms = 0;


uint8_t uart_buf[256];
uint8_t l_p = 0;
uint8_t r_p = 0;
uint8_t version_bms[20];
uint8_t inf_status_bms[50];
uint8_t voltage_cell_bms[30];

uint8_t bms_loop_st = 0;

void u_setup() {
    rcc_periph_clock_enable(RCC_USART3);
    nvic_enable_irq(NVIC_USART3_IRQ);
    gpio_set_mode(GPIOB, GPIO_MODE_OUTPUT_50_MHZ, GPIO_CNF_OUTPUT_ALTFN_PUSHPULL, GPIO10);
    gpio_set_mode(GPIOB, GPIO_MODE_INPUT, GPIO_CNF_INPUT_FLOAT, GPIO11);

	usart_set_baudrate(USART3, 9600);
	usart_set_databits(USART3, 8);
	usart_set_stopbits(USART3, USART_CR2_STOPBITS_1);
	usart_set_mode(USART3, USART_MODE_TX_RX);
	usart_set_parity(USART3, USART_PARITY_NONE);
	usart_set_flow_control(USART3, USART_FLOWCONTROL_NONE);

    /* Enable USART3 Receive interrupt. */
    // usart_enable_rx_interrupt(USART3);
    USART_CR1(USART3) |= USART_CR1_RXNEIE;
    usart_enable(USART3);
}

extern "C" void usart3_isr(void) {
    if (usart_get_flag(USART3, USART_SR_RXNE)) {
        uart_buf[r_p] = usart_recv(USART3);
        r_p++;
    }
}

void bms_loop() {

    PERIOD(100);

    uint8_t message_bms[7];

    message_bms[0] = 0xDD;
    message_bms[1] = 0xA5;
    message_bms[3] = 0x00;
    message_bms[4] = 0xFF;
    message_bms[6] = 0x77;

    switch (bms_loop_st)
    {
    case 0: {
        message_bms[2] = 0x03;
        message_bms[5] = 0xFD;
        bms_loop_st = 1;
        break;        
    }
    case 1: {
        message_bms[2] = 0x04;
        message_bms[5] = 0xFC;
        bms_loop_st = 0;
        break;        
    }
    case 2: {
        message_bms[2] = 0x05;
        message_bms[5] = 0xFB;
        bms_loop_st = 0;
        break;        
    }

    default:
        return;
        break;
    }

    u_print8(message_bms, 7);
}

// void bms_send_message() {

//     PERIOD(5000);

//     uint8_t message_bms[9];

//     message_bms[0] = 0xDD;
//     message_bms[1] = 0x5A;
//     message_bms[2] = 0xE1;
//     message_bms[3] = 0x02;
//     message_bms[4] = 0x00;
//     message_bms[5] = 0x03;
//     message_bms[6] = 0xFF;
//     message_bms[7] = 0x1A;
//     message_bms[8] = 0x77;

//     u_print8(message_bms, 9);
// }

void check_message() {

    if (l_p == r_p) { 
        return;
    }

    // search start code
    if (uart_buf[l_p] != START_CODE) {
        uart_buf[l_p] = '\0';
        ++l_p;
        return;
    }
    
    // search stop code
    uint8_t data_len = 0;
    uint8_t temp_l_p = l_p + 1;
    while (temp_l_p != r_p) {
        if (uart_buf[temp_l_p] == END_CODE) { 
            data_len = uart_buf[l_p + 3]; // checking data length
            if (data_len == temp_l_p - l_p - 6) { // -6 (start, code, stat, len, crc16)
                break;
            } else {
                ++temp_l_p;
            }
        }
        else { ++temp_l_p; }
    }
    if (temp_l_p == r_p) { return; }

    // crc calculation
    uint16_t message_crc = (((uint16_t)uart_buf[l_p + 4 + data_len]) << 8) + uart_buf[l_p + 5 + data_len];
    uint16_t crc16 = 0;
    for (auto i = l_p + 2; i < l_p + 2 + data_len + 2; ++i) {
        crc16 -= uart_buf[i];
    }

    if (message_crc == crc16) {
        uint8_t command_code = uart_buf[l_p + 1];
        switch (command_code) {
            case BASIC_INFORMATION_AND_STATUS: {
                memcpy(inf_status_bms, uart_buf + l_p + 4, 38);
                last_message_bms = millis();
                bms_connect = true;
                break;
            }
            case VOLTAGE_OF_CELL_BLOCK: { // 24
                memcpy(voltage_cell_bms, uart_buf + l_p + 4, 24);
                last_message_bms = millis();
                bms_connect = true;
                break;       
            }
            case BMS_VERSION: { // с 4 по 13 индекс(включительно), версия BMS в ASCII.
                memcpy(version_bms, uart_buf + l_p + 4, 17);
                last_message_bms = millis();
                bms_connect = true;
                break;
            }
            default: {
                break;        
            }

        }
    }
}

bool check_connect_bms() {
    if (millis() - last_message_bms >= CONNECTION_TIMEOUT)
    {
        // printf("No connect DC");
        bms_connect = 0;
        flag_charge = 0;
        return false;
    }

    return true;
}

void u_print(const char* str) {
    while (*str) {
        usart_send_blocking(USART3, *str);
        str++;
    }
}

void u_print8(const uint8_t* arr, uint8_t len) {
    while (len) {
        usart_send_blocking(USART3, *arr);
        arr++;
        len--;
    }
}