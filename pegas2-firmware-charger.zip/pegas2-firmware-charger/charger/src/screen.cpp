#include "screen.h"
#include "gpio_setup.h"
#include <gpio.hpp>
// #include "system.h"
#include <string.h>
#include "can.h"
#include <stdio.h>
#include "charge.h"
#include <uavcan.h>
#include "uart.h"
#include "button.h"

#define GET_BALANCE_STATUS ((((uint32_t)inf_status_bms[12] << 8) + inf_status_bms[13] << 8) + inf_status_bms[14] << 8) + inf_status_bms[15]

extern uint8_t can_data[8];
extern struct p_s pover_supply;

static u8g2_t u8g2;

volatile uint8_t screen_data = 0;
volatile uint8_t status_charge = 0; // 0 no battery, 1 ready, 2 balancing, 3 charging, 4 complite
static uint32_t last_update = 0;

extern BatteryInfoAux b_i_a;
extern BatteryInfo b_i;

static const uint8_t image_logo_2_bits[] = {0x00, 0xf8, 0x00, 0x00, 0x00, 0x00, 0x00, 0xfc, 0x01, 0x00, 0x00, 0x00, 0x00, 0xfe, 0x03, 0x00, 0x00, 0x00, 0x00, 0xfe, 0x03, 0x00, 0x00, 0x00, 0x00, 0xfe, 0x03, 0x00, 0x00, 0x00, 0x00, 0xfe, 0x03, 0x00, 0x00, 0x00, 0x00, 0xfe, 0x01, 0x00, 0x00, 0x00, 0x00, 0xfc, 0x01, 0x00, 0x00, 0x00, 0x00, 0x70, 0x0f, 0x1e, 0x00, 0x00, 0x00, 0xc0, 0x3f, 0x7f, 0x00, 0x00, 0x00, 0xc0, 0xbf, 0x7f, 0x00, 0x00, 0x00, 0xc0, 0xbf, 0xff, 0x00, 0x00, 0x00, 0xc0, 0xff, 0xff, 0x00, 0x00, 0x00, 0xc0, 0xbf, 0x7f, 0x00, 0x00, 0x00, 0xc0, 0xbf, 0x7f, 0x00, 0x00, 0x00, 0x80, 0x1f, 0x7f, 0x00, 0x00, 0x3c, 0xf8, 0x0f, 0xde, 0x83, 0x07, 0xfe, 0xfc, 0x01, 0xf0, 0xc7, 0x0f, 0xff, 0xfe, 0x01, 0xf0, 0xef, 0x1f, 0xff, 0xfe, 0x03, 0xf8, 0xef, 0x1f, 0xff, 0xfe, 0x03, 0xf8, 0xef, 0x3f, 0xff, 0xfe, 0x03, 0xf8, 0xef, 0x3f, 0xff, 0xfe, 0x03, 0xf0, 0xef, 0x1f, 0xfe, 0xfc, 0x01, 0xf0, 0xc7, 0x0f, 0x3c, 0xf8, 0x0f, 0xde, 0x83, 0x07, 0x00, 0x80, 0x1f, 0x7f, 0x00, 0x00, 0x00, 0xc0, 0xbf, 0x7f, 0x00, 0x00, 0x00, 0xc0, 0xbf, 0x7f, 0x00, 0x00, 0x00, 0xc0, 0xff, 0xff, 0x00, 0x00, 0x00, 0xc0, 0xbf, 0xff, 0x00, 0x00, 0x00, 0xc0, 0xbf, 0x7f, 0x00, 0x00, 0x00, 0xc0, 0x3f, 0x7f, 0x00, 0x00, 0x00, 0x00, 0x0f, 0xfe, 0x03, 0x00, 0x00, 0x00, 0x00, 0xe0, 0x07, 0x00, 0x00, 0x00, 0x00, 0xf0, 0x0f, 0x00, 0x00, 0x00, 0x00, 0xf8, 0x0f, 0x00, 0x00, 0x00, 0x00, 0xf8, 0x0f, 0x00, 0x00, 0x00, 0x00, 0xf8, 0x0f, 0x00, 0x00, 0x00, 0x00, 0xf0, 0x0f, 0x00, 0x00, 0x00, 0x00, 0xf0, 0x07, 0x00, 0x00, 0x00, 0x00, 0xe0, 0x07, 0x00};
static const uint8_t image_Charging_lightning_mask_bits[] = {0x01, 0x00, 0x02, 0x00, 0x04, 0x00, 0x08, 0x00, 0x1e, 0x00, 0x3c, 0x00, 0x08, 0x00, 0x10, 0x00, 0x20, 0x00, 0x40, 0x00};
static const uint8_t image_check_bits[] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x10, 0x00, 0x30, 0x00, 0x60, 0x80, 0xc0, 0xc1, 0x80, 0x63, 0x00, 0x36, 0x00, 0x1c, 0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
static const uint8_t image_crossed_bits[] = {0x00, 0x00, 0x00, 0x00, 0xc0, 0x60, 0xe0, 0xe0, 0x71, 0xc0, 0x3b, 0x80, 0x1f, 0x00, 0x0e, 0x00, 0x1f, 0x00, 0x3b, 0x80, 0x71, 0xc0, 0xe0, 0xe0, 0xc0, 0x60, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
static const uint8_t image_cross_small_bits[] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xc0, 0xc0, 0x61, 0x80, 0x33, 0x00, 0x1e, 0x00, 0x0c, 0x00, 0x1e, 0x00, 0x33, 0x00, 0x61, 0x80, 0xc0, 0xc0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};

void spi_setup()
{
    rcc_periph_clock_enable(RCC_SPI1);

    spi_disable(SPI1);

    spi_init_master(SPI1,
                    SPI_CR1_BAUDRATE_FPCLK_DIV_32,
                    SPI_CR1_CPOL_CLK_TO_0_WHEN_IDLE,
                    SPI_CR1_CPHA_CLK_TRANSITION_1,
                    SPI_CR1_DFF_8BIT,
                    SPI_CR1_MSBFIRST);

    spi_disable_crc(SPI1);
    spi_enable_ss_output(SPI1);
    spi_disable_software_slave_management(SPI1);

    spi_enable(SPI1);
    last_update = millis();
}

uint8_t u8x8_byte_4wire_hw_spi(u8x8_t *u8x8, uint8_t msg, uint8_t arg_int,
                               void *arg_ptr)
{
    switch (msg)
    {
    case U8X8_MSG_BYTE_SEND:
        uint8_t *data;
        data = (uint8_t *)arg_ptr;
        while (arg_int > 0)
        {
            spi_xfer(SPI1, (uint8_t)*data);
            data++;
            arg_int--;
        }
        break;
    case U8X8_MSG_BYTE_INIT:
        break;
    case U8X8_MSG_BYTE_SET_DC:
        screen_miso->write(arg_int);
        break;
    case U8X8_MSG_BYTE_START_TRANSFER:
        break;
    case U8X8_MSG_BYTE_END_TRANSFER:
        break;
    default:
        return 0;
    }
    return 1;
}

uint8_t u8g2_gpio_and_delay_stm32(U8X8_UNUSED u8x8_t *u8x8, U8X8_UNUSED uint8_t msg, U8X8_UNUSED uint8_t arg_int, U8X8_UNUSED void *arg_ptr)
{
    switch (msg)
    {
    case U8X8_MSG_GPIO_AND_DELAY_INIT:
        break;
    case U8X8_MSG_DELAY_MILLI:
        delay(arg_int);
        break;

    case U8X8_MSG_DELAY_NANO:
        for (int i = 0; i < 100; i++)
            asm("nop");
        break;
    case U8X8_MSG_GPIO_SPI_CLOCK:
        break;

    case U8X8_MSG_GPIO_SPI_DATA:
        break;

    case U8X8_MSG_GPIO_CS:
        break;

    case U8X8_MSG_GPIO_DC:
        break;
    case U8X8_MSG_GPIO_RESET:
        break;

    default:
        return 0;
    }
    return 1;
}

void draw_logo()
{
    u8g2_ClearBuffer(&u8g2);

    u8g2_SetBitmapMode(&u8g2, 1);

    u8g2_SetFontMode(&u8g2, 1);

    u8g2_DrawXBM(&u8g2, 33, 11, 48, 41, image_logo_2_bits);

    u8g2_SetFont(&u8g2, u8g2_font_4x6_tr);

    u8g2_DrawStr(&u8g2, 4, 62, FIRMWARE_VERSION);

    u8g2_SendBuffer(&u8g2);
}

void screen_setup()
{

    spi_setup();

    u8g2_Setup_ssd1322_nhd_128x64_f(&u8g2, U8G2_MIRROR_VERTICAL,
                                    u8x8_byte_4wire_hw_spi,
                                    u8g2_gpio_and_delay_stm32);

    u8g2_InitDisplay(&u8g2);
    u8g2_SetPowerSave(&u8g2, 0);

    draw_logo();
}

void draw_input()
{
    u8g2_DrawStr(&u8g2, 0, 10, "DC_Input:");

    char str[10];

    float temp = pover_supply.input_power / 1024;
    sprintf(str, "pover:   %.2f", temp);
    // u8g2_DrawStr(&u8g2, 0, 20, "pover");
    u8g2_DrawStr(&u8g2, 5, 20, str);

    temp = pover_supply.input_freq / 1024;
    sprintf(str, "freq:    %.2f", temp);
    // u8g2_DrawStr(&u8g2, 0, 30, "f");
    u8g2_DrawStr(&u8g2, 5, 30, str);

    temp = pover_supply.input_current / 1024;
    sprintf(str, "current: %.2f", temp);
    // u8g2_DrawStr(&u8g2, 0, 40, "C");
    u8g2_DrawStr(&u8g2, 5, 40, str);

    temp = pover_supply.input_voltage / 1024;
    sprintf(str, "voltage: %.2f", temp);
    // u8g2_DrawStr(&u8g2, 0, 50, "V");
    u8g2_DrawStr(&u8g2, 5, 50, str);

    temp = pover_supply.input_stage_temperature / 1024;
    sprintf(str, "temp:    %.2f", temp);
    // u8g2_DrawStr(&u8g2, 0, 60, "T");
    u8g2_DrawStr(&u8g2, 5, 60, str);
}

void draw_output()
{
    u8g2_DrawStr(&u8g2, 0, 10, "DC_Output:");

    char str[10];

    float temp = pover_supply.output_power / 1024;
    sprintf(str, "pover:   %.2f", temp);
    // u8g2_DrawStr(&u8g2, 0, 20, "P");
    u8g2_DrawStr(&u8g2, 5, 20, str);

    temp = pover_supply.output_current / 1024;
    sprintf(str, "current: %.2f", temp);
    // u8g2_DrawStr(&u8g2, 0, 30, "C");
    u8g2_DrawStr(&u8g2, 5, 30, str);

    temp = pover_supply.output_voltage / 1024;
    sprintf(str, "voltage: %.2f", temp);
    // u8g2_DrawStr(&u8g2, 0, 40, "V");
    u8g2_DrawStr(&u8g2, 5, 40, str);

    temp = pover_supply.output_stage_temperature / 1024;
    sprintf(str, "temp:    %.2f", temp);
    // u8g2_DrawStr(&u8g2, 0, 50, "T");
    u8g2_DrawStr(&u8g2, 5, 50, str);

    temp = (float)pover_supply.maximum_output_current / 10;
    sprintf(str, "max_cur: %.2f", temp);
    // u8g2_DrawStr(&u8g2, 0, 60, "M");
    u8g2_DrawStr(&u8g2, 5, 60, str);
}

void draw_b_i_a()
{
    char str[30];
    u8g2_DrawStr(&u8g2, 0, 10, "BMS_Info:");

    sprintf(str, "bms_ver: %s", version_bms); // len version 17 buf
    // u8g2_DrawStr(&u8g2, 0, 20, "pover");
    u8g2_DrawStr(&u8g2, 5, 20, str);

    // sprintf(str, "len:%d", b_i_a.info.len);
    // u8g2_DrawStr(&u8g2, 5, 20, str);

    // sprintf(str, "n_vol:%.2f", f16_to_f32(b_i_a.info.nominal_voltage));
    // u8g2_DrawStr(&u8g2, 30, 30, str);

    // sprintf(str, "b_id:%d", b_i_a.info.battery_id);
    // u8g2_DrawStr(&u8g2, 40, 20, str);


    sprintf(str, "%.3f", MV_2_V(UINT16_2_FLOAT(voltage_cell_bms[0], voltage_cell_bms[1])));
    u8g2_DrawStr(&u8g2, 5, 40, str);
    sprintf(str, "%.3f", MV_2_V(UINT16_2_FLOAT(voltage_cell_bms[2], voltage_cell_bms[3])));
    u8g2_DrawStr(&u8g2, 5, 50, str);
    sprintf(str, "%.3f", MV_2_V(UINT16_2_FLOAT(voltage_cell_bms[4], voltage_cell_bms[5])));
    u8g2_DrawStr(&u8g2, 5, 60, str);

    sprintf(str, "%.3f", MV_2_V(UINT16_2_FLOAT(voltage_cell_bms[6], voltage_cell_bms[7])));
    u8g2_DrawStr(&u8g2, 35, 40, str);
    sprintf(str, "%.3f", MV_2_V(UINT16_2_FLOAT(voltage_cell_bms[8], voltage_cell_bms[9])));
    u8g2_DrawStr(&u8g2, 35, 50, str);
    sprintf(str, "%.3f", MV_2_V(UINT16_2_FLOAT(voltage_cell_bms[10], voltage_cell_bms[11])));
    u8g2_DrawStr(&u8g2, 35, 60, str);

    sprintf(str, "%.3f", MV_2_V(UINT16_2_FLOAT(voltage_cell_bms[12], voltage_cell_bms[13])));
    u8g2_DrawStr(&u8g2, 65, 40, str);
    sprintf(str, "%.3f", MV_2_V(UINT16_2_FLOAT(voltage_cell_bms[14], voltage_cell_bms[15])));
    u8g2_DrawStr(&u8g2, 65, 50, str);
    sprintf(str, "%.3f", MV_2_V(UINT16_2_FLOAT(voltage_cell_bms[16], voltage_cell_bms[17])));
    u8g2_DrawStr(&u8g2, 65, 60, str);

    sprintf(str, "%.3f", MV_2_V(UINT16_2_FLOAT(voltage_cell_bms[18], voltage_cell_bms[19])));
    u8g2_DrawStr(&u8g2, 95, 40, str);
    sprintf(str, "%.3f", MV_2_V(UINT16_2_FLOAT(voltage_cell_bms[20], voltage_cell_bms[21])));
    u8g2_DrawStr(&u8g2, 95, 50, str);
    sprintf(str, "%.3f", MV_2_V(UINT16_2_FLOAT(voltage_cell_bms[22], voltage_cell_bms[23])));
    u8g2_DrawStr(&u8g2, 95, 60, str);
}

void draw_b_i()
{
    char str[10];

    u8g2_DrawStr(&u8g2, 0, 10, "BMS_Info:");

    // sprintf(str, "b_id: %d", b_i.info.battery_id);
    // u8g2_DrawStr(&u8g2, 5, 30, str);

    sprintf(str, "temp: %.1f", (float)((((uint16_t)inf_status_bms[23] << 8) + inf_status_bms[24]) - 2731) / 10);
    u8g2_DrawStr(&u8g2, 5, 40, str);

    sprintf(str, "%.1f", (float)((((uint16_t)inf_status_bms[25] << 8) + inf_status_bms[26]) - 2731) / 10);
    u8g2_DrawStr(&u8g2, 70, 40, str);

    sprintf(str, "%.1f", (float)((((uint16_t)inf_status_bms[27] << 8) + inf_status_bms[28]) - 2731) / 10);
    u8g2_DrawStr(&u8g2, 100, 40, str);

    sprintf(str, "volt: %.2f", MV_2_V(UINT16_2_FLOAT(inf_status_bms[0], inf_status_bms[1]) * 10));
    u8g2_DrawStr(&u8g2, 5, 50, str);

    sprintf(str, "curr: %.2f", MV_2_V(UINT16_2_FLOAT(inf_status_bms[2], inf_status_bms[3]) * 10));
    u8g2_DrawStr(&u8g2, 5, 60, str);
}

void draw_main_screen() {

    u8g2_SetFont(&u8g2, u8g2_font_7x13_t_cyrillic);
    char str[10];
    float voltage = (((float)pover_supply.output_voltage / 1024) + MV_2_V(UINT16_2_FLOAT(inf_status_bms[0], inf_status_bms[1]) * 10)) / 2;
    sprintf(str, "%.1fV", voltage);
    u8g2_DrawStr(&u8g2, 1, 12, str);

    float current = (((float)pover_supply.output_current / 1024) + MV_2_V(UINT16_2_FLOAT(inf_status_bms[2], inf_status_bms[3]) * 10)) / 2;
    sprintf(str, "%.1fA", current);
    u8g2_DrawStr(&u8g2, 40, 12, str);

    float power = voltage * current;
    sprintf(str, "%.0fW", power);
    u8g2_DrawStr(&u8g2, 1, 25, str);

    u8g2_SetFont(&u8g2, u8g2_font_5x7_t_cyrillic);

    sprintf(str, "H:%.3f",max_voltage_cell());
    u8g2_DrawStr(&u8g2, 1, 54, str);
    sprintf(str, "L:%.3f", min_voltage_cell());
    u8g2_DrawStr(&u8g2, 40, 54, str);
    sprintf(str, "D:%.3f", diff_voltage_cell());
    u8g2_DrawStr(&u8g2, 1, 64, str);
    sprintf(str, "A:%.3f", ave_voltage_cell());
    u8g2_DrawStr(&u8g2, 40, 64, str);

    float residual_capasity = MV_2_V(UINT16_2_FLOAT(inf_status_bms[4], inf_status_bms[5]) * 10);
    sprintf(str, "Ah:%.1f", residual_capasity); // Ah
    u8g2_DrawStr(&u8g2, 1, 40, str);

    sprintf(str, "%.1f%s", residual_capasity / (MV_2_V(UINT16_2_FLOAT(inf_status_bms[6], inf_status_bms[7]) * 10) / 100), "%"); // %заряда
    u8g2_DrawStr(&u8g2, 40, 40, str);

    u8g2_DrawVLine(&u8g2, 75, 0, 64);
}

void draw_voltage_cell() {

    u8g2_SetFont(&u8g2, u8g2_font_5x7_t_cyrillic);

    char str[10];

    sprintf(str, "%.2f", MV_2_V(UINT16_2_FLOAT(voltage_cell_bms[0], voltage_cell_bms[1])));
    u8g2_DrawStr(&u8g2, 80, 10, str);
    sprintf(str, "%.2f", MV_2_V(UINT16_2_FLOAT(voltage_cell_bms[2], voltage_cell_bms[3])));
    u8g2_DrawStr(&u8g2, 105, 10, str);

    sprintf(str, "%.2f", MV_2_V(UINT16_2_FLOAT(voltage_cell_bms[4], voltage_cell_bms[5])));
    u8g2_DrawStr(&u8g2, 80, 20, str);
    sprintf(str, "%.2f", MV_2_V(UINT16_2_FLOAT(voltage_cell_bms[6], voltage_cell_bms[7])));
    u8g2_DrawStr(&u8g2, 105, 20, str);

    sprintf(str, "%.2f", MV_2_V(UINT16_2_FLOAT(voltage_cell_bms[8], voltage_cell_bms[9])));
    u8g2_DrawStr(&u8g2, 80, 30, str);
    sprintf(str, "%.2f", MV_2_V(UINT16_2_FLOAT(voltage_cell_bms[10], voltage_cell_bms[11])));
    u8g2_DrawStr(&u8g2, 105, 30, str);

    sprintf(str, "%.2f", MV_2_V(UINT16_2_FLOAT(voltage_cell_bms[12], voltage_cell_bms[13])));
    u8g2_DrawStr(&u8g2, 80, 40, str);
    sprintf(str, "%.2f", MV_2_V(UINT16_2_FLOAT(voltage_cell_bms[14], voltage_cell_bms[15])));
    u8g2_DrawStr(&u8g2, 105, 40, str);

    sprintf(str, "%.2f", MV_2_V(UINT16_2_FLOAT(voltage_cell_bms[16], voltage_cell_bms[17])));
    u8g2_DrawStr(&u8g2, 80, 50, str);
    sprintf(str, "%.2f", MV_2_V(UINT16_2_FLOAT(voltage_cell_bms[18], voltage_cell_bms[19])));
    u8g2_DrawStr(&u8g2, 105, 50, str);

    sprintf(str, "%.2f", MV_2_V(UINT16_2_FLOAT(voltage_cell_bms[20], voltage_cell_bms[21])));
    u8g2_DrawStr(&u8g2, 80, 60, str);
    sprintf(str, "%.2f", MV_2_V(UINT16_2_FLOAT(voltage_cell_bms[22], voltage_cell_bms[23])));
    u8g2_DrawStr(&u8g2, 105, 60, str);
}

void draw_temp() {

    u8g2_SetFont(&u8g2, u8g2_font_5x7_t_cyrillic);

    char str[10];

    u8g2_DrawStr(&u8g2, 77, 7, "    t'C");

    sprintf(str, "%d", GET_BALANCE_STATUS);
    u8g2_DrawStr(&u8g2, 77, 17, str);

    sprintf(str, "DC: %.1f", max_current);
    u8g2_DrawStr(&u8g2, 77, 25, str);

    sprintf(str, "bms1: %.1f", (float)((((uint16_t)inf_status_bms[23] << 8) + inf_status_bms[24]) - 2731) / 10);
    u8g2_DrawStr(&u8g2, 77, 36, str);

    sprintf(str, "bms2: %.1f", (float)((((uint16_t)inf_status_bms[25] << 8) + inf_status_bms[26]) - 2731) / 10);
    u8g2_DrawStr(&u8g2, 77, 47, str);

    sprintf(str, "bms3: %.1f", (float)((((uint16_t)inf_status_bms[27] << 8) + inf_status_bms[28]) - 2731) / 10);
    u8g2_DrawStr(&u8g2, 77, 58, str);

}

void draw_setting() {

    u8g2_SetFont(&u8g2, u8g2_font_5x7_t_cyrillic);

    char str[10];

    u8g2_DrawStr(&u8g2, 77, 7, "  Setting");

    u8g2_DrawStr(&u8g2, 77, 30, "    MAX   ");
    u8g2_DrawStr(&u8g2, 77, 40, "  current ");
    sprintf(str, "   %.1fA  ", max_current);
    u8g2_DrawStr(&u8g2, 77, 50, str);
    if (setting_flag) {
        u8g2_DrawHLine(&u8g2, 92, 52, 25);
    }

    sprintf(str, "%.2f", (float)pover_supply.output_voltage / 1024);
    u8g2_DrawStr(&u8g2, 77, 54, str);
    sprintf(str, "%.2f", (float)pover_supply.output_current / 1024);
    u8g2_DrawStr(&u8g2, 77, 64, str);
    
}

void draw_data()
{

    u8g2_ClearBuffer(&u8g2);
    u8g2_SetBitmapMode(&u8g2, 1);
    u8g2_SetFontMode(&u8g2, 1);

    draw_main_screen();

    u8g2_SetFont(&u8g2, u8g2_font_5x7_t_cyrillic);

    // if (dc_connect)
    // {
    //     u8g2_DrawXBM(&u8g2, 117, 0, 12, 16, image_check_bits);
    // }
    // else
    // {
    //     u8g2_DrawXBM(&u8g2, 117, 0, 10, 16, image_cross_small_bits);
    // }

    // if (bms_connect)
    // {
    //     u8g2_DrawXBM(&u8g2, 106, 0, 12, 16, image_check_bits);
    // }
    // else
    // {
    //     u8g2_DrawXBM(&u8g2, 106, 0, 10, 16, image_cross_small_bits);
    // }

    // if (flag_charge)
    // {
    //     u8g2_DrawXBM(&u8g2, 91, 5, 9, 10, image_Charging_lightning_mask_bits);
    //     u8g2_DrawXBM(&u8g2, 95, 3, 9, 10, image_Charging_lightning_mask_bits);
    // }
    // else
    // {
    //     u8g2_DrawXBM(&u8g2, 91, 0, 10, 16, image_cross_small_bits);
    // }

    // if(!flag_balancing) {
    //     u8g2_DrawXBM(&u8g2, 117, 10, 12, 16, image_check_bits);
    // } else{
    //     u8g2_DrawXBM(&u8g2, 117, 10, 10, 16, image_cross_small_bits);
    // }

    switch (status_charge)
    {
    case 0:
        u8g2_DrawStr(&u8g2, 40, 25, "no bms");
        break;
    case 1:
        u8g2_DrawStr(&u8g2, 40, 25, "ready");
        break;
    case 2:
        u8g2_DrawStr(&u8g2, 40, 25, "V cell");
        break;
    case 3:
        u8g2_DrawStr(&u8g2, 40, 25, "charg");
        break;
    case 4:
        u8g2_DrawStr(&u8g2, 40, 25, "balanc");
        u8g2_DrawFrame(&u8g2, 0, 0, 128, 64);
        break;
    case 5:
        u8g2_DrawStr(&u8g2, 40, 25, "complit");
        u8g2_DrawFrame(&u8g2, 0, 0, 128, 64);
        break;
    case 6:
        u8g2_DrawStr(&u8g2, 40, 25, "timeout");
        u8g2_DrawFrame(&u8g2, 0, 0, 128, 64);
        break;

    default:
        break;
    }

    switch (screen_data)
    {
    case 0:
        draw_voltage_cell();
        break;
    case 1:
        draw_temp();
        break;
    case 2:
        draw_setting();
        break;
    default:
        break;
    }

    u8g2_SendBuffer(&u8g2);
}

void screen_update()
{
    if (millis() - last_update > 100)
    {
        draw_data();
        last_update = millis();
    }
}
