#pragma once

#include "gpio_setup.h"
#include <Button2.h>


extern Button2 v_button_stop;
extern Button2 v_button_left;
extern Button2 v_button_right;
extern Button2 v_button_ok;

extern bool setting_flag;

void button_setup();

