#pragma once

#define VALUE(can_data) ((((uint32_t)can_data[4] << 8) + can_data[5] << 8) + can_data[6] << 8) + can_data[7]
#define MAIN_INDEX(can_data) (can_data[1])

#define SET_VALUE(can_data, value)      \
    do                                     \
    {                                      \
        can_data[4] = value >> 24;         \
        can_data[5] = (value << 8) >> 24;  \
        can_data[6] = (value << 16) >> 24; \
        can_data[7] = (value << 24) >> 24; \
    } while (0)
#define SET_MAIN_INDEX(can_data, value) (can_data[1] = value)
#define SET_COMMAND_INDEX(can_data, value) (can_data[0] = value)
