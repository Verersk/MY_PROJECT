#pragma once

#include <libopencm3/stm32/spi.h>
#include "../modules/u8g2/csrc/u8g2.h"

#define FIRMWARE_VERSION "v2.0.1"
#define BOOT_DELAY 3000

extern volatile uint8_t screen_data;

void screen_setup();
void screen_update();