#pragma once

// #include "../../libopencm3/include/libopencm3/stm32/f1/usart.h"
#include "../../libopencm3/include/libopencm3/stm32/rcc.h"
#include "../../libopencm3/include/libopencm3/stm32/gpio.h"
#include "../../libopencm3/include/libopencm3/stm32/usart.h"
#include "../../libopencm3/include/libopencm3/stm32/f1/nvic.h"
#include "utils.h"
#include <cstdio>
#include "charge.h"

#define UINT16_2_FLOAT(data1, data2) (float)((uint16_t)data1 << 8 | data2)
#define MV_2_V(data) (data / 1000)

#define CONNECTION_TIMEOUT 2000

extern bool bms_connect;

extern uint8_t version_bms[20];
extern uint8_t inf_status_bms[50];
extern uint8_t voltage_cell_bms[30];

void u_setup();
void u_print(const char* str);
void u_print8(const uint8_t* arr, uint8_t len);
void bms_loop();
void check_message();
bool check_connect_bms();
void bms_send_message();