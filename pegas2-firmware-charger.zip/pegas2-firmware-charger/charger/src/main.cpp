#include "gpio_setup.h"
// #include "system.h"

#include <uavcan.h>

#include <libopencm3/cm3/scb.h> // scb_reset_core();

#include "macros.h"
#include "screen.h"
#include "button.h"

#include "can.h"
#include "charge.h"
#include "uart.h"

extern uint8_t can_data[8];
extern struct p_s pover_supply;

void blink()
{
    int period = 100;
    if ((millis() / period) % 2) {
        led0->on();
    }
    else {
        led0->off();
    }
}

void heat_control(bool on)
{
    on ? heater_ctrl->on() : heater_ctrl->off();
}

// std::unique_ptr<System> System::instance = std::make_unique<System>();
// std::unique_ptr<BQ769> BQ769::instance = std::make_unique<BQ769>();
// std::unique_ptr<UAVCAN> UAVCAN::instance = std::make_unique<UAVCAN>();
// std::unique_ptr<Heating> Heating::instance = std::make_unique<Heating>();

// void shell_commands()
// {

//     shell_add_command("reboot", [](EmbeddedCli *cli, char *args, void *context)
//                       { scb_reset_core(); });

//     shell_add_command("p_s", [](EmbeddedCli *cli, char *args, void *context) // pover_supply 1 50
//                       {
//                           if (embeddedCliGetTokenCount(args) < 2)
//                           {
//                               return;
//                           }
//                           const uint8_t command = atoi(embeddedCliGetToken(args, 1));
//                           const uint32_t value = atoi(embeddedCliGetToken(args, 2));

//                           switch (command)
//                           {
//                           case 0x00:
//                               SET_VALUE(can_data, value * 1024);
//                               break;
//                           case 0x01:
//                               SET_VALUE(can_data, value * 1024);
//                               break;
//                           case 0x02:
//                               SET_VALUE(can_data, value * 1024);
//                               break;
//                           case 0x03:
//                               SET_VALUE(can_data, value * 30);
//                               break;
//                           case 0x04:
//                               SET_VALUE(can_data, value);
//                               break;

//                           default:
//                               // printf("eroor command\r\n");
//                               return;
//                               break;
//                           }

//                           SET_COMMAND_INDEX(can_data, 0x01);
//                           SET_MAIN_INDEX(can_data, command);

//                           while (can_transmit(CAN1, 0x108180FE, true, false, 8, can_data) == -1)
//                           {
//                               // printf("mailbox busy\r\n");
//                               // delay(100);
//                               for (size_t i = 0; i < 500000; ++i)
//                               {
//                                   __asm__("NOP");
//                               }
//                           }
//                           // printf("Send command message\r\n");
//                       });
// }

// void print_ps()
// {
//     printf("\r\nInput:\r\n");
//     printf("InP: %d\r\n", pover_supply.input_power);
//     printf("InV: %d\r\n", pover_supply.input_voltage);
//     printf("InC: %d\r\n", pover_supply.input_current);
//     printf("IST: %d\r\n", pover_supply.input_stage_temperature);
//     printf("InF: %d\r\n", pover_supply.input_freq);

//     printf("Eff: %d\r\n", pover_supply.efficiency);

//     printf("\r\nOutput:\r\n");
//     printf("OuP: %d\r\n", pover_supply.output_power);
//     printf("OuV: %d\r\n", pover_supply.output_voltage);
//     printf("OuC: %d\r\n", pover_supply.output_current);
//     printf("OST: %d\r\n", pover_supply.output_stage_temperature);

//     printf("MOC: %d\r\n", pover_supply.maximum_output_current);
// }

int main()
{
    rcc_clock_setup_pll(&rcc_hsi_configs[RCC_CLOCK_HSI_64MHZ]);
    systick_setup();
    gpio_setup();
    // shell_setup();
    can_setup();
    // shell_commands();
    u_setup();
    screen_setup();

    auto uavcan = UAVCAN::get_instance();
    uavcan->setup();

    button_setup();

    subscribe_messages();
    delay(1000);

    for (;;)
    {
        // shell_tick();
        blink();
        screen_update();

        v_button_stop.loop();
        v_button_left.loop();
        v_button_right.loop();
        v_button_ok.loop();

        dc_loop();
        bms_loop();
        check_message();
        check_connect_dc();

        // bms_send_message();

        charge_loop();

    }
    
}
