#include "charge.h"
#include "can.h"
#include <uavcan.h>
#include "uart.h"
// #include "system.h"

#define GET_BALANCE_STATUS ((((uint32_t)inf_status_bms[12] << 8) + inf_status_bms[13] << 8) + inf_status_bms[14] << 8) + inf_status_bms[15]

extern BatteryInfoAux b_i_a; // побаночно
extern BatteryInfo b_i;

uint8_t flag_charge = 0;
uint8_t flag_balancing = 0;
uint8_t charge_complite = 0;
uint8_t post_charge = 0;
extern uint8_t dc_connect;
extern uint8_t battary_connect;

float output_voltage = 0;
float max_current = 30;
float temp_voltage = 0;

#define TIMEOUT_BALANCE (uint32_t)3600000
uint32_t time_start_balance = 0; 

float max_voltage_cell() {
    float voltage = 0;
    for (size_t i = 0; i < 24; i += 2)
    {
        if (MV_2_V(UINT16_2_FLOAT(voltage_cell_bms[i], voltage_cell_bms[i+1])) > voltage)
        {
            voltage = MV_2_V(UINT16_2_FLOAT(voltage_cell_bms[i], voltage_cell_bms[i+1]));
        }
    }
    return voltage;
}

float min_voltage_cell() {
    float voltage = 5.0f;
    for (size_t i = 0; i < 24; i += 2)
    {
        if (MV_2_V(UINT16_2_FLOAT(voltage_cell_bms[i], voltage_cell_bms[i+1])) < voltage)
        {
            voltage = MV_2_V(UINT16_2_FLOAT(voltage_cell_bms[i], voltage_cell_bms[i+1]));
        }
    }
    return voltage;
}

float ave_voltage_cell() {
    float voltage = 0;
    for (size_t i = 0; i < 24; i += 2)
    {
        voltage += MV_2_V(UINT16_2_FLOAT(voltage_cell_bms[i], voltage_cell_bms[i+1]));
    }
    return voltage / 12;
}

float diff_voltage_cell() {
    return max_voltage_cell() - min_voltage_cell();
}

uint8_t check_battery()
{

    float min_voltage = min_voltage_cell();
    float max_voltage = max_voltage_cell();

    if(max_voltage >= 4.22f || max_voltage <= 1.0f) {
        flag_charge = 0;
        charge_complite = 1;
        post_charge = 0;
        return 0;
    }

    if (max_voltage - min_voltage >= 0.20f)
    {
        return 0;
    }

    return 1;
}

void charge_loop()
{
    PERIOD(100);
    
    if (flag_charge && dc_connect && bms_connect)
    {
        if (check_battery())
        {
            if (!time_start_balance) {
                time_start_balance = millis();
            }
            float bat_voltage = (((float)pover_supply.output_voltage / 1024) + MV_2_V(UINT16_2_FLOAT(inf_status_bms[0], inf_status_bms[1]) * 10)) / 2;
            if (bat_voltage <= 50.0f && !charge_complite && !post_charge) // проверить общее напряжение на акб
            {
                float current = (((float)pover_supply.output_current / 1024) + MV_2_V(UINT16_2_FLOAT(inf_status_bms[2], inf_status_bms[3]) * 10)) / 2;
                if (current < (max_current - 2.5f) && current > (max_current + 2.5f)) {
                    
                } else if (current < max_current && ((bat_voltage + temp_voltage) < 50.40f)) {
                    temp_voltage += 0.004;
                } else if (current > max_current && temp_voltage > 0) {
                    temp_voltage -= 0.004;
                }

                output_voltage = bat_voltage + temp_voltage;
                can_tr_mesage(0x108180FE, 0x01, 0x00, output_voltage * 1024);
                can_tr_mesage(0x108180FE, 0x01, 0x02, max_current * 1024);
                can_tr_mesage(0x108180FE, 0x01, 0x03, max_current / 50 * 1024);
                // can_tr_mesage(0x108180FE, 0x01, 0x04, 30.0f / 50 * 1024);
                status_charge = 3;
                time_start_balance = millis(); // время начала балансировки
            }
            else if (GET_BALANCE_STATUS != 0xffffffff || GET_BALANCE_STATUS != 0x00000000) // напряжение >= 50V, выставляю напряжение 50V и ждем пока ток >= 1A
            {
                if (millis() < time_start_balance + TIMEOUT_BALANCE) {
                    uint32_t output_voltage = 50.40f * 1024;

                    can_tr_mesage(0x108180FE, 0x01, 0x00, output_voltage);
                    can_tr_mesage(0x108180FE, 0x01, 0x02, 4.0f / 10 * 1024);
                    can_tr_mesage(0x108180FE, 0x01, 0x03, 4.0f / 10 / 50 * 1024);
                    // can_tr_mesage(0x108180FE, 0x01, 0x04, 7.0f / 50 * 1024);
                    status_charge = 4;
                    post_charge = 1;
                } else {
                    status_charge = 6;
                    can_tr_mesage(0x108180FE, 0x01, 0x03, 0 * 30);
                    // flag_charge = 0;
                    // time_start_balance= 0;

                    charge_complite = 1;
                    post_charge = 0;
                    temp_voltage = 0;
                }


            }
            else // зарядка ненужна/завершена
            {
                can_tr_mesage(0x108180FE, 0x01, 0x03, 0 * 30);
                flag_charge = 0;
                time_start_balance= 0;

                charge_complite = 1;
                post_charge = 0;
                temp_voltage = 0;
            }
        }
        else // требуется балансировка
        {
            can_tr_mesage(0x108180FE, 0x01, 0x03, 0 * 30);
            status_charge = 2;
            temp_voltage = 0;
        }
    }
    else // не заряжать
    {
        if (!bms_connect)
        {
            status_charge = 0;
            charge_complite = 0;
        }
        else if (charge_complite)
        {
            status_charge = 5;
        }
        else if (!flag_charge && dc_connect && bms_connect)
        {
            status_charge = 1;
        }
        time_start_balance = 0;

        can_tr_mesage(0x108180FE, 0x01, 0x00, 41.5 * 1024);
        can_tr_mesage(0x108180FE, 0x01, 0x03, 0 * 30);
    }
}
