#pragma once

extern uint8_t flag_charge;
extern uint8_t flag_balancing;
extern volatile uint8_t status_charge;
extern uint8_t charge_complite;
extern uint8_t post_charge;

extern float output_voltage;
extern float max_current;
extern float temp_voltage;

void charge_loop();

float max_voltage_cell();
float min_voltage_cell();
float ave_voltage_cell();
float diff_voltage_cell();