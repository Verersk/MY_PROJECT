#include "gpio_setup.h"


PIN* mcu_status_leds;
PIN* comm_led;
PIN* button;
PIN* power_hold;
PIN* precharge_keys;
PIN* open_keys;
PIN* iso_dcdc_en;

PIN* heater_ctrl;

PIN* batt_heat1;
PIN* batt_heat2;
PIN* batt_heat3;
PIN* batt_heat4;
PIN* batt_heat5;
PIN* batt_heat6;

PIN* vbat_measure_on;
PIN* vbat_sens;

PIN* current_measure_on;
PIN* current_sens;

PIN* batt_temp_pad1;
PIN* batt_temp_pad2;

PIN* screen_led1;
PIN* screen_led2;
PIN* screen_led3;
PIN* screen_led4;

void enable_adc1() {
    rcc_peripheral_enable_clock(&RCC_APB2ENR,RCC_APB2ENR_ADC1EN);
    adc_power_off(ADC1);
    rcc_peripheral_reset(&RCC_APB2RSTR,RCC_APB2RSTR_ADC1RST);
    rcc_peripheral_clear_reset(&RCC_APB2RSTR,RCC_APB2RSTR_ADC1RST);
    rcc_set_adcpre(RCC_CFGR_ADCPRE_PCLK2_DIV8);
    adc_set_dual_mode(ADC_CR1_DUALMOD_IND);		// Independent mode
    adc_disable_scan_mode(ADC1);
    adc_set_right_aligned(ADC1);
    adc_set_single_conversion_mode(ADC1);

    adc_power_on(ADC1);
    adc_reset_calibration(ADC1);
    adc_calibrate_async(ADC1);
    while ( adc_is_calibrating(ADC1) );
}


void gpio_setup() {
    rcc_periph_clock_enable(RCC_AFIO);
    gpio_primary_remap(AFIO_MAPR_SWJ_CFG_JTAG_OFF_SW_ON | AFIO_MAPR_CAN1_REMAP_PORTB, 0);
    rcc_periph_clock_enable(RCC_GPIOA);
    rcc_periph_clock_enable(RCC_GPIOB);
    rcc_periph_clock_enable(RCC_GPIOC);
    rcc_periph_clock_enable(RCC_GPIOD);
    enable_adc1();

    mcu_status_leds = (new PIN(GPIOC, 8))->off();
    iso_dcdc_en = (new PIN(GPIOC, 11))->on();
    precharge_keys = (new PIN(GPIOC, 10))->inv()->on();
    open_keys = (new PIN(GPIOA, 15))->inv()->off();
    comm_led = (new PIN(GPIOC, 9))->off();
    button = (new PIN(GPIOA, 2, MODE::INPUT));
    power_hold = (new PIN(GPIOA, 3))->off();
    heater_ctrl = (new PIN(GPIOB, 2))->off();

    gpio_set_mode(GPIO_BANK_CAN1_PB_RX, GPIO_MODE_INPUT,
        GPIO_CNF_INPUT_PULL_UPDOWN, GPIO_CAN_PB_RX);
    gpio_set(GPIO_BANK_CAN1_PB_RX, GPIO_CAN_PB_RX);
    /* Configure CAN pin: TX. */
    gpio_set_mode(GPIO_BANK_CAN1_PB_TX, GPIO_MODE_OUTPUT_50_MHZ,
        GPIO_CNF_OUTPUT_ALTFN_PUSHPULL, GPIO_CAN_PB_TX);

    batt_heat1 = new PIN(GPIOC, 4, MODE::INPUT_ANALOG, ADC_CHANNEL14);
    batt_heat2 = new PIN(GPIOA, 7, MODE::INPUT_ANALOG, ADC_CHANNEL7);
    batt_heat3 = new PIN(GPIOB, 1, MODE::INPUT_ANALOG, ADC_CHANNEL9);
    batt_heat4 = new PIN(GPIOC, 5, MODE::INPUT_ANALOG, ADC_CHANNEL15);
    batt_heat5 = new PIN(GPIOA, 6, MODE::INPUT_ANALOG, ADC_CHANNEL6);
    batt_heat6 = new PIN(GPIOB, 0, MODE::INPUT_ANALOG, ADC_CHANNEL8);

    vbat_measure_on = (new PIN(GPIOC, 3))->on();
    vbat_sens = new PIN(GPIOA, 1, MODE::INPUT_ANALOG, ADC_CHANNEL1);

    current_measure_on = (new PIN(GPIOC, 2))->on();
    current_sens = new PIN(GPIOA, 0, MODE::INPUT_ANALOG, ADC_CHANNEL0);

    batt_temp_pad1 = new PIN(GPIOA, 4, MODE::INPUT_ANALOG, ADC_CHANNEL4);
    batt_temp_pad2 = new PIN(GPIOA, 5, MODE::INPUT_ANALOG, ADC_CHANNEL5);

    screen_led1 = (new PIN(GPIOB, 12))->off();
    screen_led2 = (new PIN(GPIOB, 13))->off();
    screen_led3 = (new PIN(GPIOB, 14))->off();
    screen_led4 = (new PIN(GPIOB, 15))->off();
}
