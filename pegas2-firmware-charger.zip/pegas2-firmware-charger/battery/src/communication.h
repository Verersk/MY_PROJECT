#include <bq769.h>


void pub_batt_cells_info();
void pub_batt_info();
void pub_dcdc_input_info();
void pub_dcdc_output_info();
void subscribe_messages();
void publish_messages();

#define UAVCAN_ARMING_STATUS_ID 1100

#define UAVCAN_PROTOCOL_CELLS_INFO_ID              20004   
#define UAVCAN_PROTOCOL_CELLS_INFO_SIGNATURE       0x7d7f49fc75484882

#define UAVCAN_PROTOCOL_BATTERY_INFO_ID              1092   
#define UAVCAN_PROTOCOL_BATTERY_INFO_SIGNATURE       0x249c26548a711966


#pragma pack(1)
typedef union {
  struct {
    unsigned timestamp_l: 28;
    unsigned timestamp_h: 28;
    unsigned len: 8;
    uint16_t voltage_cell[12];
    uint16_t cycle_count;
    uint16_t over_discharge_count;
    unsigned max_current: 16;
    unsigned nominal_voltage: 16;
    unsigned is_powering_off: 1;
    uint8_t battery_id;
  } info;
  uint8_t buff[42];
} BatteryInfoAux;

typedef union {
  struct {
    unsigned temperature: 16;
    unsigned voltage: 16;
    unsigned current: 16;
    unsigned average_power_10sec: 16;
    unsigned remaining_capacity_wh: 16;
    unsigned full_charge_capacity_wh: 16;
    unsigned hours_to_full_charge: 16;
    unsigned status_flags: 11;
    unsigned state_of_health_pct: 7;

    unsigned state_of_charge_pct: 7;
    unsigned state_of_charge_pct_stdev: 7;

    uint8_t battery_id;
    uint32_t model_instance_id: 32;

    uint8_t model_name[32];
  } info;
  uint8_t buff[55];
} BatteryInfo;
#pragma pack(0)


