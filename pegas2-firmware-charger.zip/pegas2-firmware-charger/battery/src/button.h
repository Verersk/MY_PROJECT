#include "gpio_setup.h"
#include <Button2.h>

void button_setup();

extern Button2 main_button;