#include "system.h"
#include <bq769.h>
#include <heating.h>


void System::commands_setup() {
    shell_add_command("bq769_regs", [](EmbeddedCli *cli, char *args, void *context) {
        auto bq = BQ769::get_instance();
        bq->print_registers();
    });

    shell_add_command("bq769_cells", [](EmbeddedCli *cli, char *args, void *context) {
        auto bq = BQ769::get_instance();
        bq->print_cells();
    });

    shell_add_command("voltage", [](EmbeddedCli *cli, char *args, void *context) {
        auto system = System::get_instance();
        printf("System voltage: %fv\n\r", system->get_batt_voltage());
    });

    shell_add_command("temp", [](EmbeddedCli *cli, char *args, void *context) {
        auto system = System::get_instance();
        printf("System temperature: %f*C\n\r", system->get_batt_temp_degc());
    });

    shell_add_command("current", [](EmbeddedCli *cli, char *args, void *context) {
        auto system = System::get_instance();
        printf("System current: %fA\n\r", system->get_batt_current());
    });

    shell_add_command("heating", [](EmbeddedCli *cli, char *args, void *context) {
        auto heating = Heating::get_instance();
        heating->print_state();
    });

    Parameters::_list.init_commands();
}
