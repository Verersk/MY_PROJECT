/*
    Вспомогательный модуль хранящий состояние системы
*/
#pragma once
#ifndef SYSTEM_H
#define SYSTEM_H
#include <memory>
#include <shell.h>

typedef void (*func)();
class System {
public:
    System() {};
    static System* get_instance() {
        return instance.get();
    }

    bool is_on() { return is_system_on; }

    void on() {
        this->is_system_on = true;
        if (_on_clb != nullptr) _on_clb();
    }

    void set_on_callback(func f) { _on_clb = f; }

    void off() {
        this->is_system_on = false;
        if (_off_clb != nullptr) _off_clb();
    }

    void set_off_callback(func f) { _off_clb = f; }

    void toggle() { this->is_system_on ? this->off() : this->on(); }
    void commands_setup();
    auto get_batt_voltage() -> f32;
    auto get_batt_current() -> f32;
    auto get_batt_temp_degc() -> f32;
    void indication();

private:
    static std::unique_ptr<System> instance;
    bool is_system_on = false;
    func _off_clb = nullptr;
    func _on_clb = nullptr;
};
#endif