#include "gpio_setup.h"
#include "button.h"
#include "system.h"

#include <soft-i2c.h>
#include <bq769.h>
#include "communication.h"

#include <uavcan.h>
#include <heating.h>
#include <utils.h>

void blink() {
    auto system = System::get_instance();
    int period = system->is_on() ? 1000 : 100;
    if ((millis() / period) % 2) {
        mcu_status_leds->on();
    } else {
        mcu_status_leds->off();
    }
}

auto read_temp(uint16_t adc) -> f32 {
    const float INPUT_V = 3.3;
    const float OUTPUT_V = linear_interpolation(0.f, INPUT_V, (float)adc, 0.f, 4095.f);
    const float R1_kOm = 47;
    const float T1_kOm = ((INPUT_V * R1_kOm) / OUTPUT_V) - R1_kOm;
    return (1.0/(1.0/(273.15+25.f) + 1.0 / 3550 * log(T1_kOm  / 10.f))) - 273.15;
}

void heat_control(bool on) {
    on ? heater_ctrl->on() : heater_ctrl->off();
}

std::unique_ptr<System> System::instance = std::make_unique<System>();
std::unique_ptr<BQ769> BQ769::instance = std::make_unique<BQ769>();
std::unique_ptr<UAVCAN> UAVCAN::instance = std::make_unique<UAVCAN>();
std::unique_ptr<Heating> Heating::instance = std::make_unique<Heating>();

int main() {
    rcc_clock_setup_pll(&rcc_hse_configs[RCC_CLOCK_HSE16_72MHZ]);
    systick_setup();
    gpio_setup();
    button_setup();
    shell_setup();

    auto i2c = new SoftI2C(GPIOB, GPIO10, GPIOB, GPIO11);
    auto bq = BQ769::get_instance();
    bq->set_conf(i2c, GPIOC, GPIO7);

    auto system = System::get_instance();
    system->commands_setup();
    auto uavcan = UAVCAN::get_instance()->setup();

    system->set_on_callback([]() {
        power_hold->on();
        open_keys->on();
        precharge_keys->on();
    });

    system->set_off_callback([]() {
        auto bq = BQ769::get_instance();
        power_hold->off();
        bq->discharge_off();
        open_keys->off();
        precharge_keys->off();
    });

    auto heating = Heating::get_instance();

    heating->add_heater(
        heat_control,
        []() -> f32 { return read_temp(batt_heat1->analog_read()); }
    );

    heating->add_heater(
        heat_control,
        []() -> f32 { return read_temp(batt_heat2->analog_read()); }
    );
    heating->add_heater(
        heat_control,
        []() -> f32 { return read_temp(batt_heat3->analog_read()); }
    );
    heating->add_heater(
        heat_control,
        []() -> f32 { return read_temp(batt_heat4->analog_read()); }
    );
    heating->add_heater(
        heat_control,
        []() -> f32 { return read_temp(batt_heat5->analog_read()); }
    );
    heating->add_heater(
        heat_control,
        []() -> f32 { return read_temp(batt_heat6->analog_read()); }
    );
    bq->discharge_off();
    u8 data[] = {1,2,3,4,5,6,7,8};
    for (;;) {
        if (millis() > 2500) {
            open_keys->on();
        }
        // const int tx_res = can_transmit(
        //     CAN1,
        //     0x123,
        //     true, false,
        //     8,
        //     (uint8_t*)data
        // );
        // printf("tx_res %d\n\r", tx_res);
        shell_tick();
        system->indication();
        blink();
        // heating->tick();
        if (system->is_on()) {
            bq->balance();
        } else {
            bq->discharge_off();
        }
        main_button.loop();
        publish_messages();
        system->get_batt_current();
        // printf("System current: %fA\n\r", system->get_batt_current());
    }
}
