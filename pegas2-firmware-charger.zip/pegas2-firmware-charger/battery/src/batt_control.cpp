#include "system.h"
#include <utils.h>
#include "gpio_setup.h"
#include <cmath>

#define SHUNT_RESIST_OHM 0.001
#define OUTPUT_RESIST_KOHM  33


auto System::get_batt_voltage() -> f32 {
    /* 3908.86 - максимальный ацп для делителя с резисторами 150кОм и 10 кОм */
    return linear_interpolation(0, 50.4, vbat_sens->analog_read(), 0, 3908.86);
}

auto System::get_batt_current() -> f32 {
    static f32 acc_current = 0;
    static u8 number_of_measurements = 0;
    auto adc = current_sens->analog_read() * 2.02f; // 2.02f поправочный коэффициент
    static f32 val = 0;
    float sens_val = (adc * 3.3) / 4095.f;
    float ampere = sens_val / (OUTPUT_RESIST_KOHM * SHUNT_RESIST_OHM);
    // printf("%fA\n\r", ampere);
    if (ampere <= 0) {
        return val;
    }
    number_of_measurements++;
    acc_current += ampere;
    val = acc_current / number_of_measurements;

    if (number_of_measurements == 200) {
        acc_current = 0;
        number_of_measurements = 0;
    }
    return val;
}

auto _read_temp(uint16_t adc) -> f32 {
    const float INPUT_V = 3.3;
    const float OUTPUT_V = linear_interpolation(0.f, INPUT_V, (float)adc, 0.f, 4095.f);
    const float R1_kOm = 10;
    const float T1_kOm = ((INPUT_V * R1_kOm) / OUTPUT_V) - R1_kOm;
    return (1.0/(1.0/(273.15+25.f) + 1.0 / 3550 * log(T1_kOm  / 5.f))) - 273.15;
}

auto System::get_batt_temp_degc() -> f32 {
    return _read_temp(batt_temp_pad1->analog_read()) + _read_temp(batt_temp_pad2->analog_read()) / 2;
}

void System::indication() {
    PERIOD(5000);
    auto voltage = get_batt_voltage();
    screen_led1->off();
    screen_led2->off();
    screen_led3->off();
    screen_led4->off();

    if (voltage > 38.f) {
        screen_led1->on();
    }

    if (voltage > 42.f) {
        screen_led2->on();
    }

    if (voltage > 45.f) {
        screen_led3->on();
    }

    if (voltage > 49.f) {
        screen_led4->on();
    }
}
