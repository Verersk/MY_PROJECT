#include "communication.h"
#include <uavcan.h>
#include "system.h"
#include <heating.h>


void pub_batt_cells_info() {
    // PERIOD(1000);
    auto bq = BQ769::get_instance();
    auto uavcan = UAVCAN::get_instance();

    BatteryInfoAux info = {.info = {
        .len = 12,
        .nominal_voltage = f32_to_f16(50),
        .battery_id = 0,
    }};
    for(int i = 0; i < 12; i++)
        info.info.voltage_cell[i] = f32_to_f16(bq->get_cell_voltage(i));
    info.buff[0] = 10;
    uavcan->broadcast(
        UAVCAN_PROTOCOL_CELLS_INFO_ID,
        UAVCAN_PROTOCOL_CELLS_INFO_SIGNATURE,
        info.buff,
        42);
}

void pub_batt_info() {
    //PERIOD(1000);
    auto uavcan = UAVCAN::get_instance();
    auto system = System::get_instance();

    BatteryInfo info = {.info = {
        .temperature = f32_to_f16(273 + system->get_batt_temp_degc()),
        .voltage = f32_to_f16(system->get_batt_voltage()),
        .current = f32_to_f16(system->get_batt_current()),
        .battery_id = 0,
    }};
    uavcan->broadcast(
        UAVCAN_PROTOCOL_BATTERY_INFO_ID,
        UAVCAN_PROTOCOL_BATTERY_INFO_SIGNATURE,
        info.buff,
        23);
}

void subscribe_messages() {
    UAVCAN::add_handler(UAVCAN_ARMING_STATUS_ID, 0, [](CanardInstance* ins, CanardRxTransfer* transfer) {
        auto system = System::get_instance();
        // system->arming_handler(ins, transfer);
    });
}

void publish_messages() {
    auto uavcan = UAVCAN::get_instance();
    auto heating = Heating::get_instance();

    uavcan->send();
    uavcan->tick();

    PERIOD(50);
    static u8 message_id = 0;
    message_id++;
    switch (message_id) {
    case 1:
        return pub_batt_cells_info();
    case 2:
        return pub_batt_info();
    // case 3:
        // return heating->pub_info_to_uavcan();
    default:
        message_id = 0;
    }
}
