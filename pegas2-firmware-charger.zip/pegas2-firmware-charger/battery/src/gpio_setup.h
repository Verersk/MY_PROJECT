#pragma once
#include <gpio.hpp>
#include <systick.h>


extern PIN* button;
extern PIN* mcu_status_leds;
extern PIN* comm_led;
extern PIN* power_hold;
extern PIN* precharge_keys;
extern PIN* open_keys;
extern PIN* iso_dcdc_en;

extern PIN* heater_ctrl;

extern PIN* batt_heat1;
extern PIN* batt_heat2;
extern PIN* batt_heat3;
extern PIN* batt_heat4;
extern PIN* batt_heat5;
extern PIN* batt_heat6;

extern PIN* vbat_measure_on;
extern PIN* vbat_sens;

extern PIN* current_measure_on;
extern PIN* current_sens;

extern PIN* batt_temp_pad1;
extern PIN* batt_temp_pad2;

extern PIN* screen_led1;
extern PIN* screen_led2;
extern PIN* screen_led3;
extern PIN* screen_led4;

void gpio_setup();

void adc_setup();
