#include "button.h"
#include "system.h"


Button2 main_button;

void button_setup() {
    main_button.begin(BTN_VIRTUAL_PIN);
    main_button.setLongClickTime(3000);

    main_button.setButtonStateFunction([]() -> uint8_t {
        return static_cast<uint8_t>(button->get_state());
    });

    main_button.setLongClickDetectedHandler([](Button2& btn) {
        auto system = System::get_instance();
        system->toggle();
    });

    main_button.setPressedHandler([](Button2& btn) {
        comm_led->on();
    });

    main_button.setReleasedHandler([](Button2& btn) {
        auto system = System::get_instance();
        if (not system->is_on()) {
            /* выключение всего если отпустили кнопку раньше чем через 3с, нужно для правильной работы предзаряда */
            system->off();
        }
        comm_led->off();
    });
}
